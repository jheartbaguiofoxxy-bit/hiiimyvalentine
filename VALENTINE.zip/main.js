console.log('Hello World!');

<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.2/dist/confetti.browser.min.js"></script>

<script>
particlesJS('particles-js', {
  particles: {
    number: { value: 80 },         // more particles = denser glitter
    color: { value: "#fff" },      // white or yellow sparkles
    shape: { type: "circle" },
    opacity: { value: 0.8, random: true },
    size: { value: 2, random: true },
    move: {
      enable: true,
      speed: 0.6,                  // slow floating effect
      direction: "top",
      random: true,
      out_mode: "out"
    }
  },
  interactivity: {
    detect_on: "canvas",
    events: { onhover: { enable: false }, onclick: { enable: false } }
  }
});
</script>
